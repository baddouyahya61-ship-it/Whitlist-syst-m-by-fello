import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X } from "lucide-react";

const links = [
  { to: "/", label: "Accueil" },
  { to: "/rules", label: "Rules" },
  { to: "/gangs", label: "Gangs" },
  { to: "/links", label: "Links" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-md border-b border-border">
      <div className="container flex items-center justify-between h-16">
        <Link to="/" className="font-display text-3xl text-primary tracking-widest">
          LARUE
        </Link>

        {/* Desktop */}
        <div className="hidden md:flex gap-8">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className={`font-display text-lg tracking-wider transition-colors hover:text-primary ${
                pathname === l.to ? "text-primary" : "text-foreground"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </div>

        {/* Hamburger */}
        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)}>
          {open ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-background/95 backdrop-blur-md border-b border-border">
          {links.map((l, i) => (
            <Link
              key={l.to}
              to={l.to}
              onClick={() => setOpen(false)}
              className={`block px-6 py-4 font-display text-xl tracking-wider border-b border-border transition-colors animate-slide-in hover:text-primary ${
                pathname === l.to ? "text-primary" : "text-foreground"
              }`}
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              {l.label}
            </Link>
          ))}
        </div>
      )}
    </nav>
  );
}
