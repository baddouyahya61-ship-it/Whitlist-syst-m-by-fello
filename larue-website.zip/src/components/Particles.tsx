import { useEffect, useRef } from "react";

export default function Particles() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const particles: HTMLDivElement[] = [];
    for (let i = 0; i < 30; i++) {
      const p = document.createElement("div");
      const size = Math.random() * 4 + 2;
      p.style.cssText = `
        position:absolute;
        width:${size}px;height:${size}px;
        background:hsl(25 100% 50% / ${Math.random() * 0.6 + 0.2});
        border-radius:50%;
        left:${Math.random() * 100}%;
        bottom:-10px;
        animation: particle-rise ${Math.random() * 6 + 4}s linear infinite;
        animation-delay: ${Math.random() * 6}s;
      `;
      el.appendChild(p);
      particles.push(p);
    }
    return () => particles.forEach((p) => p.remove());
  }, []);

  return <div ref={ref} className="fixed inset-0 pointer-events-none z-0 overflow-hidden" />;
}
