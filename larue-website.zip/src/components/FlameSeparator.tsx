export default function FlameSeparator() {
  return (
    <div className="flex items-center justify-center gap-2 py-8">
      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
      <span className="text-primary text-2xl">🔥</span>
      <div className="h-px flex-1 bg-gradient-to-r from-transparent via-primary to-transparent" />
    </div>
  );
}
