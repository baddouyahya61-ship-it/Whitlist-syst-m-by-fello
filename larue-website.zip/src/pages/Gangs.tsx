import { motion } from "framer-motion";
import groveImg from "@/assets/gang-grove.png";
import ballasImg from "@/assets/gang-ballas.png";
import vagosImg from "@/assets/gang-vagos.png";
import blastImg from "@/assets/gang-blast.png";
import dragonImg from "@/assets/dragon.png";

const gangs = [
  {
    name: "Grove Street Families",
    color: "grove",
    borderClass: "border-grove",
    textClass: "text-grove",
    shadowClass: "shadow-[0_0_30px_hsl(120_60%_40%/0.3)]",
    logo: groveImg,
    desc: "La famille originale de Grove Street. Loyauté, honneur et respect des territoires. Menée par les OG du quartier, cette famille contrôle les rues de Los Santos depuis des générations.",
    territory: "Ganton, Idlewood",
  },
  {
    name: "Ballas",
    color: "ballas",
    borderClass: "border-ballas",
    textClass: "text-ballas",
    shadowClass: "shadow-[0_0_30px_hsl(270_60%_45%/0.3)]",
    logo: ballasImg,
    desc: "Les rivaux mortels de Grove Street. Violents et ambitieux, les Ballas cherchent à dominer chaque coin de rue. Leur purple représente le pouvoir et la domination.",
    territory: "Glen Park, Jefferson",
  },
  {
    name: "Los Santos Vagos",
    color: "vagos",
    borderClass: "border-vagos",
    textClass: "text-vagos",
    shadowClass: "shadow-[0_0_30px_hsl(45_100%_50%/0.3)]",
    logo: vagosImg,
    desc: "Le gang latino le plus puissant de Los Santos. Les Vagos contrôlent le marché avec une main de fer. Leur jaune brille dans les rues d'East Los Santos.",
    territory: "East Los Santos, Las Colinas",
  },
  {
    name: "Blast",
    color: "blast",
    borderClass: "border-blast",
    textClass: "text-blast",
    shadowClass: "shadow-[0_0_30px_hsl(120_100%_45%/0.3)]",
    logo: blastImg,
    desc: "Le gang le plus explosif de Los Santos! Blast frappe vite et fort. Connus pour leurs opérations éclair et leur audace, ils sont imprévisibles et dangereux. Le vert néon, c'est leur signature.",
    territory: "Flint County, Whetstone",
  },
];

export default function Gangs() {
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container">
        <motion.div className="text-center mb-12" initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
          <h1 className="font-display text-6xl text-primary">LES GANGS</h1>
          <p className="text-muted-foreground mt-2">Choisis ton camp. Défends ton territoire.</p>
        </motion.div>

        {/* Dragon divider */}
        <div className="flex justify-center mb-12">
          <img src={dragonImg} alt="Dragon" className="w-48 opacity-60 animate-float" loading="lazy" width={1024} height={768} />
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {gangs.map((g, i) => (
            <motion.div
              key={g.name}
              className={`bg-card border-2 ${g.borderClass} rounded-lg overflow-hidden hover-lift animate-breathe ${g.shadowClass}`}
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: i * 0.15 }}
            >
              <div className="flex items-center gap-4 p-6">
                <img src={g.logo} alt={g.name} className="w-24 h-24 object-contain" loading="lazy" width={512} height={512} />
                <div>
                  <h2 className={`font-display text-3xl ${g.textClass}`}>{g.name}</h2>
                  <p className="text-muted-foreground text-sm">📍 {g.territory}</p>
                </div>
              </div>
              <div className="px-6 pb-6">
                <p className="text-foreground">{g.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
