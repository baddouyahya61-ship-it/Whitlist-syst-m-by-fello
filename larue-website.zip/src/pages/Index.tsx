import { motion } from "framer-motion";
import { ChevronDown, Users, Shield, Gamepad2, Zap } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";
import dragonImg from "@/assets/dragon.png";
import FlameSeparator from "@/components/FlameSeparator";

const features = [
  { icon: Gamepad2, title: "Roleplay Immersif", desc: "Vis ta vie à Los Santos avec des scénarios réalistes." },
  { icon: Users, title: "Communauté Active", desc: "Rejoins des centaines de joueurs passionnés." },
  { icon: Shield, title: "Anti-Cheat", desc: "Système anti-triche avancé pour un jeu fair-play." },
  { icon: Zap, title: "Événements", desc: "Gang wars, courses, missions spéciales chaque semaine." },
];

export default function Index() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <img src={heroBg} alt="Los Santos" className="absolute inset-0 w-full h-full object-cover opacity-40" width={1920} height={800} />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-transparent to-background" />

        {/* Dragon */}
        <motion.img
          src={dragonImg}
          alt="Dragon"
          className="absolute top-16 right-0 w-72 md:w-96 opacity-80 animate-float pointer-events-none"
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 0.8 }}
          transition={{ duration: 1.5 }}
          width={1024}
          height={768}
        />

        <div className="relative z-10 text-center px-4">
          <motion.h1
            className="font-display text-7xl md:text-9xl tracking-[0.2em] text-primary animate-fire"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            LARUE
          </motion.h1>
          <motion.p
            className="font-display text-2xl md:text-4xl tracking-widest text-foreground mt-4"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            TRÉ TRÉ PRÉCISIONEL
          </motion.p>
          <motion.p
            className="text-muted-foreground text-lg mt-4 max-w-xl mx-auto"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            Le serveur GTA SA:MP roleplay le plus immersif. Rejoins l'aventure maintenant.
          </motion.p>
          <motion.a
            href="samp://connect"
            className="inline-block mt-8 px-8 py-3 bg-primary text-primary-foreground font-display text-xl tracking-wider rounded-lg animate-breathe hover:scale-105 transition-transform"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            REJOINDRE LE SERVEUR
          </motion.a>
        </div>

        <ChevronDown className="absolute bottom-8 left-1/2 -translate-x-1/2 text-primary animate-bounce-arrow" size={32} />
      </section>

      {/* Features */}
      <section className="container py-20">
        <h2 className="font-display text-5xl text-center text-primary mb-12">POURQUOI LARUE ?</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              className="bg-card border border-border rounded-lg p-6 hover-lift animate-breathe text-center"
              initial={{ y: 40, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <f.icon className="mx-auto text-primary mb-4" size={40} />
              <h3 className="font-display text-2xl text-foreground mb-2">{f.title}</h3>
              <p className="text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <FlameSeparator />

      {/* Getting Started */}
      <section className="container py-20">
        <h2 className="font-display text-5xl text-center text-primary mb-12">COMMENT JOUER</h2>
        <div className="max-w-2xl mx-auto space-y-6">
          {["Télécharge GTA San Andreas", "Installe SA-MP (sa-mp.com)", "Ajoute le serveur: samp.larue.com:7777", "Crée ton personnage et joue!"].map((step, i) => (
            <motion.div
              key={i}
              className="flex items-center gap-4 bg-card border border-border rounded-lg p-4 hover-lift"
              initial={{ x: -40, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <span className="font-display text-3xl text-primary">{i + 1}</span>
              <p className="text-foreground text-lg">{step}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 text-center text-muted-foreground">
        <p className="font-display text-primary text-2xl tracking-widest">LARUE</p>
        <p className="mt-2">© 2026 Larue Roleplay — Tous droits réservés</p>
      </footer>
    </div>
  );
}
