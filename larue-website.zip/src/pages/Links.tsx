import { motion } from "framer-motion";
import { ExternalLink, MessageCircle, Download, Globe } from "lucide-react";

const links = [
  { icon: Download, label: "Télécharger SA-MP", url: "https://sa-mp.com", desc: "Client officiel SA-MP" },
  { icon: MessageCircle, label: "Discord", url: "https://discord.gg/larue", desc: "Rejoins notre communauté Discord" },
  { icon: Globe, label: "Forum", url: "https://forum.larue.com", desc: "Forum officiel du serveur" },
  { icon: ExternalLink, label: "Wiki", url: "https://wiki.larue.com", desc: "Guide complet du serveur" },
];

export default function Links() {
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container max-w-2xl">
        <motion.div className="text-center mb-12" initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
          <h1 className="font-display text-6xl text-primary">LIENS UTILES</h1>
          <p className="text-muted-foreground mt-2">Tout ce qu'il te faut pour commencer.</p>
        </motion.div>

        <div className="space-y-4">
          {links.map((l, i) => (
            <motion.a
              key={l.label}
              href={l.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 bg-card border border-border rounded-lg p-5 hover-lift group"
              initial={{ x: -30, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: i * 0.1 }}
            >
              <l.icon className="text-primary group-hover:scale-110 transition-transform" size={32} />
              <div>
                <h3 className="font-display text-xl text-foreground">{l.label}</h3>
                <p className="text-muted-foreground text-sm">{l.desc}</p>
              </div>
              <ExternalLink className="ml-auto text-muted-foreground" size={16} />
            </motion.a>
          ))}
        </div>
      </div>
    </div>
  );
}
