import { motion } from "framer-motion";
import { AlertTriangle } from "lucide-react";

const rules = [
  { title: "Respect", desc: "Respecte tous les joueurs et les admins. Aucune insulte ou harcèlement toléré." },
  { title: "Roleplay", desc: "Reste en personnage (IC) à tout moment en jeu. Pas de metagaming." },
  { title: "No Deathmatching", desc: "Tu ne peux pas tuer sans raison RP valide. Le random deathmatch est interdit." },
  { title: "Powergaming", desc: "Ne force pas des actions RP sur un autre joueur. Laisse-le répondre." },
  { title: "Cheats", desc: "Tout cheat, mod ou outil externe est interdit. Ban permanent." },
  { title: "Gangs", desc: "Les guerres de gangs doivent être RP. Pas d'attaques sans raison." },
  { title: "Véhicules", desc: "Conduis de manière réaliste. Pas de car-parking ni de spawn-kill en véhicule." },
  { title: "Admins", desc: "Les décisions des admins sont finales. Conteste via le forum." },
];

export default function Rules() {
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container max-w-3xl">
        <motion.div className="text-center mb-12" initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
          <AlertTriangle className="mx-auto text-primary mb-4" size={48} />
          <h1 className="font-display text-6xl text-primary">RÈGLES DU SERVEUR</h1>
          <p className="text-muted-foreground mt-2">Le non-respect entraîne un ban.</p>
        </motion.div>

        <div className="space-y-4">
          {rules.map((r, i) => (
            <motion.div
              key={r.title}
              className="bg-card border border-border rounded-lg p-5 hover-lift"
              initial={{ x: -30, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: i * 0.08 }}
            >
              <h3 className="font-display text-xl text-primary mb-1">{i + 1}. {r.title}</h3>
              <p className="text-muted-foreground">{r.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
